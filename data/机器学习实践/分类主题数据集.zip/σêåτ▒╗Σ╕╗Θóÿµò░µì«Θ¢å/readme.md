在线广告中，点击率（CTR）是评估广告效果的重要指标，随着机器学习技术的不断发展，通过机器学习方法构建自动广告点击预测系统也变得越来越普及。数据文件**ctr.csv**包含Avazu公司一段时间内的广告点击数据，字段及说明如下：

|字段|说明|
|--|--|
|id|用户ID|
|click|建模目标，是否点击，1为点击，0为未点击|
|C1|匿名分类变量|
|banner_pos|网页上广告位置|
|site_id|站点ID|
|site_domain|站点区域|
|site_category|站点类别|
|app_id|用户APPID|
|app_domain|用户APP区域|
|app_category|用户APP类别|
|device_id|设备ID|
|device_ip|设备IP|
|device_model|设备模型|
|device_type|设备类型|
|device_conn_type|设备接入类型|
|C14-C21|未知分类变量|

数据文件已被分为三部分，训练集**ctr_train.csv**、训练集标签**ctr_labels.csv**和测试集**ctr_test.csv**. 基于训练集数据建立并训练CTR预估模型，输出测试集上的预测概率. 本项目选择使用测试集的二分类交叉熵作为评价指标（详见sklearn.metrics.log_loss）.
